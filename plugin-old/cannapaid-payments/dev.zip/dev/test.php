<?php
$num = null;
class Test {
    public function __construct()
    {
        $this->test = 1;
        $this->createNum();
        $this->sumNum();
    }

    public function createNum() {
        global $num;
        $num = 5;
    }

    public function sumNum() {
        global $num;
        $a = $num + $num;
        echo $a;
    }
}

new Test;