<?php
session_start();
set_time_limit(120);
/**
 * Plugin Name:       CannaPaid Payments Plugin Test
 * Plugin URI:        https://www.cannapaid.com
 * Description:       A Wordpress plugin for WooCommerce which implements credit & debit card payments via CannaPaid
 * Author:            Team Alpha
 * Version:           0.0.1
 * Requires at least: 5.2
 * Requires PHP:      5.6
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 *
 * This plugin is released under the GPLv2 License
 * (Please see the file "LICENSE" included with this plugin)
 *
 */
defined('ABSPATH') or exit;


// Make sure WooCommerce is active
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    return;
}

/**
 * Add the gateway to WC Available Gateways
 *
 * @param array $gateways all available WC gateways
 * @return array $gateways all WC gateways + Cannapaid gateway
 * @since 1.1.1
 */
function wc_cannapaid_add_to_gateways($gateways)
{
    $gateways[] = 'WC_Gateway_CannaPaid';
    return $gateways;
}

add_filter('woocommerce_payment_gateways', 'wc_cannapaid_add_to_gateways');


/**
 * Adds plugin page links
 *
 * @param array $links all plugin links
 * @return array $links all plugin links + our custom links (i.e., "Settings")
 * @since 1.1.1
 */
function wc_cannapaid_gateway_plugin_links($links)
{

    $plugin_links = array(
        '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=cannapaid_gateway') . '">' . __('Configure', 'wc-gateway-cannapaid') . '</a>'
    );

    return array_merge($plugin_links, $links);
}

add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wc_cannapaid_gateway_plugin_links');


/**
 * Cannapaid Payment Gateway
 *
 * Provides an CannaPaid Payment Gateway; mainly for testing purposes.
 * We load it later to ensure WC is loaded first since we're extending it.
 *
 * @class        WC_Gateway_CannaPaid
 * @extends        WC_Payment_Gateway
 * @version        1.1.1
 * @package        WooCommerce/Classes/Payment
 * @author        SkyVerge
 */
function wc_cannapaid_gateway_init()
{
    class WC_Gateway_CannaPaid extends WC_Payment_Gateway
    {
        const GATEWAY_NAME = 'cannapaid_gateway';
        const AUTH_TOKEN_LIVE = 'T9XU1cpC5hgls953qOLbUVmnT92S1Ml7';

        /**
         * Constructor for the gateway.
         */
        public function __construct()
        {

            $this->id = self::GATEWAY_NAME;
            $this->icon = apply_filters('woocommerce_cannapaid_icon', '');
            $this->has_fields = false;
            $this->method_title = __('CannaPaid', 'wc-gateway-cannapaid');
            $this->method_description = __('Allows CannaPaid payments.', 'wc-gateway-cannapaid');

            // Load the settings.
            $this->init_form_fields();
            $this->init_settings();

            // Define user set variables
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->redirect_form = $this->get_option('redirect_form');
            $this->token = $this->get_option('payment_token');
            $this->public_key = $this->get_option('public_key');
            $this->secret_key = $this->get_option('secret_key');

            // Filter options
            add_filter('woocommerce_settings_api_sanitized_fields_' . $this->id, array($this, 'validate_form_options'));

            // Actions
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        }

        public function validate_form_options($settings)
        {

            $token = $settings['payment_token'];
            $public_key = $settings['public_key'];
            $secret_key = $settings['secret_key'];
            $redirect_form = $settings['redirect_form'];
            $description = $settings['description'];
            if (!$token) {
                $errorMessage = 'Form Token is required';
                echo '<div id="message" class="notice notice-error is-dismissible"><p>' . $errorMessage . '</p></div>';
                return $settings;
            }
            if (!$description) {
                $settings['description'] = ' ';
            }
            if (empty($public_key) || empty($secret_key)) {
                $errorMessage = 'API Keys are required to switch on embed form mode';
                if ($redirect_form) {
                    echo '<div id="message" class="notice notice-error is-dismissible"><p>' . $errorMessage . '</p></div>';
                    $settings['redirect_form'] = 0;
                    return $settings;
                }
            }

            $decode_token = json_decode(base64_decode(str_replace('_', '/', str_replace('-', '+', explode('.', $token)[1]))));
            $api_url = $decode_token->api_url;

            if (!empty($public_key) || !empty($secret_key)) {
                $response_key_validate = wp_remote_get("{$api_url}/api/transaction-process/healthcheck/open", array(
                    'method' => 'GET',
                    'data_format' => 'body',
                    'headers' => array(
                        'Content-Type' => 'application/json',
                        'PublicKey' => $public_key,
                        'SecretKey' => $secret_key,
                    ),
                    'body' => null,
                ));
                $response_key_body_validate = $response_key_validate['body'];
                $response_key_body_validate_json = json_decode($response_key_body_validate, TRUE);
                if (isset($response_key_body_validate_json['status'])) {
                    if (!$response_key_body_validate_json['status']) {
                        $error_message = 'Invalid secret key or public key';
                        echo '<div id="message" class="notice notice-error is-dismissible"><p>' . $error_message . '</p></div>';
                        $settings['public_key'] = '';
                        $settings['secret_key'] = '';
                        $settings['redirect_form'] = 0;
                        return $settings;
                    }
                }
            }

            $body = array(
                'token' => $token,
                'domain' => get_site_url(),
            );

            $request = wp_remote_post("{$api_url}/api/form-token/verify", array(
                'method' => 'POST',
                'data_format' => 'body',
                'headers' => array(
                    'Content-Type' => 'application/json',
                ),
                'body' => json_encode($body),
            ));

            $response = json_decode($request['body']);

            if (isset($response->status)) {
                if (!$response->status) {
                    $errorMessage = $response->error; //$errorMessage = $response->errorMessage;
                    echo '<div id="message" class="notice notice-error is-dismissible"><p>' . $errorMessage . '</p></div>';
                    $settings['payment_token'] = '';
                }
            }

            return $settings;
        }

        /**
         * Initialize Gateway Settings Form Fields
         */
        public function init_form_fields()
        {
            $fields = $this->get_fields();
            $this->form_fields = apply_filters('wc_cannapaid_form_fields', $fields);
        }

        public function get_fields()
        {
            return array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'wc-gateway-cannapaid'),
                    'type' => 'checkbox',
                    'label' => __('Enable Cannapaid Payment', 'wc-gateway-cannapaid'),
                    'default' => 'yes'
                ),

                'title' => array(
                    'title' => __('Title', 'wc-gateway-cannapaid'),
                    'type' => 'text',
                    'description' => __('This controls the title for the payment method the customer sees during checkout.', 'wc-gateway-cannapaid'),
                    'default' => __('Cannapaid Payment', 'wc-gateway-cannapaid'),
                    'desc_tip' => true,
                ),

                'redirect_form' => array(
                    'title' => __('Form/Redirect', 'wc-gateway-cannapaid'),
                    'type' => 'select',
                    'options' => [__('Redirect', 'wc-gateway-cannapaid'), __('Embed Form', 'wc-gateway-cannapaid')],
                ),

                'description' => array(
                    'title' => __('Description', 'wc-gateway-cannapaid'),
                    'type' => 'textarea',
                    'description' => __('Use your Visa, Mastercard or Discover cards to pay for your order (AMEX not currently supported!)', 'wc-gateway-cannapaid'),
                    'default' => __('', 'wc-gateway-cannapaid'),
                    'desc_tip' => true,
                ),

                'payment_token' => array(
                    'title' => __('Form token', 'wc-gateway-cannapaid'),
                    'type' => 'textarea',
                    'description' => __('Token for generate Cannapaid Payment form.', 'wc-gateway-cannapaid'),
                    'default' => '',
                    'desc_tip' => true,
                ),

                'public_key' => array(
                    'title' => __('Public Key', 'wc-gateway-cannapaid'),
                    'type' => 'textarea',
                    'description' => __('Token for generate Cannapaid Payment form.', 'wc-gateway-cannapaid'),
                    'default' => '',
                    'desc_tip' => true,
                ),

                'secret_key' => array(
                    'title' => __('Secret Key', 'wc-gateway-cannapaid'),
                    'type' => 'textarea',
                    'description' => __('Token for generate Cannapaid Payment form.', 'wc-gateway-cannapaid'),
                    'default' => '',
                    'desc_tip' => true,
                ),
            );
        }

        public function payment_fields()
        {
            if (!$this->redirect_form) {
                echo wpautop(wptexturize($this->description));
                return;
            }

            $decode_token = json_decode(base64_decode(str_replace('_', '/', str_replace('-', '+', explode('.', $this->token)[1]))));
            $api_url = $decode_token->api_url;
            $request = wp_remote_post("{$api_url}/api/transaction-process/disclaimer/open", array(
                'method' => 'POST',
                'data_format' => 'body',
                'headers' => array(
                    'SecretKey' => $this->secret_key,
                    'PublicKey' => $this->public_key,
                    'Content-Type' => 'application/json',
                ),
                'body' => json_encode(array(
                    'token' => $this->token,
                )),
            ));
            $response_body_disclaimer = $request['body'];
            $response_body_disclaimer_json = json_decode($response_body_disclaimer, TRUE);
            if (isset($response_body_disclaimer_json['status'])) {
                if (!$response_body_disclaimer_json['status']) {
                    $error_message = $response_body_disclaimer_json['error'];
                    echo "<div class='woocommerce-NoticeGroup woocommerce-NoticeGroup-checkout'><ul class='woocommerce-error' style='margin-bottom: 0;' role='alert'><li>$error_message</li></ul></div>";
                    return;
                }
            }
            $disclaimer_version = $response_body_disclaimer_json['disclaimer_version'];
            $_SESSION['disclaimer_version'] = $disclaimer_version;
            $response_disclaimer_json = $response_body_disclaimer_json['disclaimer'];

            $checkout = WC()->checkout();
            $billing_country = $checkout->get_value('billing_country');
            $order_amount = $this->get_order_total();
            $request_fee = wp_remote_post("{$api_url}/api/transaction-process/amount/open", array(
                'method' => 'POST',
                'data_format' => 'body',
                'headers' => array(
                    'SecretKey' => $this->secret_key,
                    'PublicKey' => $this->public_key,
                    'Content-Type' => 'application/json',
                ),
                'body' => json_encode(array(
                    'token' => $this->token,
                    'amount' => (float)$order_amount,
                    'country' => $billing_country,
                )),
            ));
            $response_body_fee = $request_fee['body'];
            $response_body_fee_json = json_decode($response_body_fee, TRUE);
            if (isset($response_body_fee_json['status'])) {
                if (!$response_body_fee_json['status']) {
                    $error_message = $response_body_fee_json['error'];
                    echo "<div class='woocommerce-NoticeGroup woocommerce-NoticeGroup-checkout'><ul class='woocommerce-error' style='margin-bottom: 0;' role='alert'><li>$error_message</li></ul></div>";
                    return;
                }
            }
            $customer_fee = $response_body_fee_json['customer_fee'];
            if (trim($this->description)) {
                echo wpautop(wptexturize($this->description));
            }

            // I will echo() the form, but you can close PHP tags and print it directly in HTML
            echo '<fieldset id="wc-' . esc_attr($this->id) . '-cc-form" class="wc-credit-card-form wc-payment-form" style="background:transparent;">';

            // Add this action hook if you want your custom payment gateway to support it
            do_action('woocommerce_credit_card_form_start', $this->id);

            // I recommend to use inique IDs, because other gateways could already use #ccNo, #expdate, #cvc
            echo '
                <div class="form-row form-row-wide"><label>Card Number <span class="required">*</span></label>
                    <input id="canna_ccNo" name="canna_ccNo" type="text" maxlength="16" size="16" autocomplete="off" style="width: 100%;padding-left: 7px;">
                    </div>
                    <div class="form-row form-row-first">
                        <label> Card Expiration Date <span class="required">*</span></label>
                    
                         <span class="expiration">
                            <input type="text" id="canna_month" name="month" placeholder="MM" maxlength="2" size="2" style="width: 60px;padding-left: 6px;"/>
                            <span>/</span>
                            <input type="text" id="canna_year" name="year" placeholder="YY" maxlength="2" size="2" style="width: 60px;padding-left: 10px;"/>
                        </span>
                    </div>
                    <div class="form-row form-row-last">
                        <label>Card Code (CVV) <span class="required">*</span></label>
                        <input id="canna_cvv" name="canna_cvv" type="password" maxlength="4" size="4" autocomplete="off" placeholder="CVV" style="width: 100%;padding-left: 8px;">
                    </div>
                <div class="clear"></div>';
            echo '<script>
            var cvvElement = document.getElementById("canna_cvv");
            var cardElement = document.getElementById("canna_ccNo");
            var monthElement = document.getElementById("canna_month");
            var yearElement = document.getElementById("canna_year");
            cvvElement.addEventListener("input", checkNumber);
            cardElement.addEventListener("input", checkNumber);
            monthElement.addEventListener("input", checkNumber);
            yearElement.addEventListener("input", checkNumber);
            function checkNumber(e) {
                const text = e.target.value;
                const myRe = new RegExp(/^\d+$/)
                if (!myRe.exec(text)) e.target.value = text.slice(0, text.length - 1);
            }
//            function checkCard(e) {
//                const text = e.target.value;
//                const myRe = new RegExp(/^\d+$/)
//                if (!myRe.exec(text)) cardElement.value = text.slice(0, text.length - 1);
//            }
            </script>';

            echo "<div style='font-size: 13px; font-weight: bold;'>A $$customer_fee transaction fee will should be applied to your purchase</div>";

            echo "<div style='font-size: 11px; margin-top: 7px;'>{$response_disclaimer_json['en']}</div>";

            echo '<div style="display: flex; margin-top: 7px; align-items: center; margin-bottom: 5px;"><input onchange="check1()" type="checkbox" style="margin-right: 9px;" id="token_disclaimer_pay"><label for="token_disclaimer_pay" style="font-size: 11px">I understand I am purchasing a token from ';
            echo "{$response_body_disclaimer_json['company_name']} <span class='required'>*</span></label></div>";
            echo '<div style="display: flex; align-items: center;"><input onchange="check2()" type="checkbox" style="margin-right: 9px;" name="token_disclaimer_transfer" id="token_disclaimer_transfer"><label for="token_disclaimer_transfer" style="font-size: 11px">I agree to transfer my token to ';
            echo "{$response_body_disclaimer_json['site_name']} as a form of payment <span class='required'>*</span></label></div>";
            echo '<input id="token_disclaimer_pay_checker" name="token_disclaimer_pay_checker" type="hidden" value="0">';
            echo '<input id="token_disclaimer_transfer_checker" name="token_disclaimer_transfer_checker" type="hidden" value="0">';
            echo '<script>
                function check1() {
                    const chbox1 = document.getElementById("token_disclaimer_pay");
                    const chboxValue1 = document.getElementById("token_disclaimer_pay_checker")
                    chboxValue1.value = chbox1.checked ? "1" : "0";
                }
                function check2() {
                    const chbox2 = document.getElementById("token_disclaimer_transfer");
                    const chboxValue2 = document.getElementById("token_disclaimer_transfer_checker")
                    chboxValue2.value = chbox2.checked ? "1" : "0";
                }
            </script>';

            do_action('woocommerce_credit_card_form_end', $this->id);

            echo '<div class="clear"></div></fieldset>';
        }


        /**
         * Process the payment and return the result
         *
         * @param int $order_id
         * @return array
         */
        public function process_payment($order_id)
        {
            global $wp;
            $checkout = WC()->checkout();
            $order = wc_get_order($order_id);
            if (is_null($order)) {
                $error_message = 'Order not found';
                error_log($error_message);
                return array('result' => 'failure', 'messages' => $error_message);
            }

            $payment_methods = WC()->payment_gateways->payment_gateways();
            $cannapaid_gateway = $payment_methods[self::GATEWAY_NAME];

            if (is_null($cannapaid_gateway)) {
                $error_message = 'Payment method not found';
                error_log($error_message);
                return array('result' => 'failure', 'messages' => $error_message);
            }

            $order_amount = $order->get_total();
            $redirect = $cannapaid_gateway->get_return_url($order);
            $home_url = home_url(add_query_arg(array(), $wp->request));

            $settings = $cannapaid_gateway->settings;
            $payment_token = $settings['payment_token'];
            $public_key = $settings['public_key'];
            $secret_key = $settings['secret_key'];

            $decode_token = json_decode(base64_decode(str_replace('_', '/', str_replace('-', '+', explode('.', $payment_token)[1]))));
            $api_url = $decode_token->api_url;
//            $agent_id = $decode_token->

            $checkout_data = json_encode(array(
                'firstName' => $checkout->get_value('billing_first_name'),
                'lastName' => $checkout->get_value('billing_last_name'),
                'address' => $checkout->get_value('billing_address_1'),
                'city' => $checkout->get_value('billing_city'),
                'postCode' => $checkout->get_value('billing_postcode'),
                'country' => $checkout->get_value('billing_country'),
                'state' => $checkout->get_value('billing_state'),
                'email' => $checkout->get_value('billing_email'),
                'phone' => $checkout->get_value('billing_phone'),
            ));

            $auth_token = self::AUTH_TOKEN_LIVE;
            $plugin_data = get_plugin_data(__FILE__);
            $plugin_version = $plugin_data['Version'];

            $body = array(
                'token' => $payment_token,
                'order_id' => $order_id,
                'amount' => (float)$order_amount,
                'redirect_url' => $redirect,
                'home_url' => $home_url,
                'device_type' => 'web',
                'customer_data' => $checkout_data,
                'plugin_version' => $plugin_version,
                'user_agent' => $_SERVER['HTTP_USER_AGENT'],
            );

            if (empty($public_key) || empty($secret_key)) {
                $request = wp_remote_post("{$api_url}/api/order/session/init", array(
                    'method' => 'POST',
                    'data_format' => 'body',
                    'headers' => array(
                        'authorization' => $auth_token,
                        'Content-Type' => 'application/json',
                    ),
                    'body' => json_encode($body),
                ));
            } else {
                $request = wp_remote_post("{$api_url}/api/order/session/init/open", array(
                    'method' => 'POST',
                    'data_format' => 'body',
                    'headers' => array(
                        'SecretKey' => $secret_key,
                        'PublicKey' => $public_key,
                        'Content-Type' => 'application/json',
                    ),
                    'body' => json_encode($body),
                ));
            }
            $response_body = $request['body'];
            $response_body_json = json_decode($response_body, TRUE);

            if (!$response_body_json['success']) {
                $error_message = $response_body_json['error'];
                error_log($error_message);
                throw new Exception(__($error_message, 'wc-gateway-cannapaid'));
            }

            $form_url = json_decode($request['body'])->form_url;

            if (is_null($form_url)) {
                $error_message = 'Payment form url not found';
                error_log($error_message);
                return array('result' => 'failure', 'messages' => $error_message);
            }

            if ($this->redirect_form) {
                if (!$checkout->get_value('token_disclaimer_pay_checker') || !$checkout->get_value('token_disclaimer_transfer_checker')) {
                    throw new Exception(__('You must agree to the terms and conditions before placing your order', 'wc-gateway-cannapaid'));
                }

                $disclaimer_version = $_SESSION['disclaimer_version'];
                $body_transaction = [
                    'token' => $payment_token,
                    'customer' => [
                        'first_name' => $checkout->get_value('billing_first_name'),
                        'last_name' => $checkout->get_value('billing_last_name'),
                        'phone' => $checkout->get_value('billing_phone'),
                        'email' => $checkout->get_value('billing_email'),
                        'address' => [
                            'city' => $checkout->get_value('billing_city'),
                            'zip' => $checkout->get_value('billing_postcode'),
                            'country' => $checkout->get_value('billing_country'),
                            'state' => $checkout->get_value('billing_state'),
                            'address1' => $checkout->get_value('billing_address_1'),
                        ],
                        'card' => [
                            'number' => $checkout->get_value('canna_ccNo'),
                            'year' => '20' . $checkout->get_value('year'),
                            'month' => $checkout->get_value('month'),
                            'cvv' => $checkout->get_value('canna_cvv'),
                        ],
                    ],
                    'amount' => (float)$order_amount,
                    'order_id' => $order_id,
                    'disclaimer_version' => (int)$disclaimer_version,
                ];
                $request = wp_remote_post("{$api_url}/api/transaction-process/do-transaction/open", array(
                    'method' => 'POST',
                    'timeout' => 1,
                    'data_format' => 'body',
                    'headers' => array(
                        'SecretKey' => $secret_key,
                        'PublicKey' => $public_key,
                        'Content-Type' => 'application/json',
                    ),
                    'body' => json_encode($body_transaction),
                ));

                $response_body = $request['body'];
                $response_body_json = json_decode($response_body, TRUE);
                if (!$response_body_json['status']) {
//                    throw new Exception(__($response_body_json['error'], 'wc-gateway-cannapaid'));
                    throw new Exception(__("ERROR", 'wc-gateway-cannapaid'));
                }

                if ($response_body_json['transaction_id']) {
                    if ($order->get_total() > 0) {
                        // Mark as processing or on-hold (payment won't be taken until delivery).
                        $order->update_status(apply_filters('woocommerce_cod_process_payment_order_status', $order->has_downloadable_item() ? 'on-hold' : 'processing', $order), __('Payment to be made upon delivery.', 'woocommerce'));
                    } else {
                        $order->payment_complete();
                    }
                    WC()->cart->empty_cart();
                    $_SESSION["redirect_url"] = $this->get_return_url($order);
                    $redirect_path = plugin_dir_url(__FILE__) . 'status.php?transaction_id=' . $response_body_json['transaction_id'] . '&order_id=' . $order_id;
                    return array(
                        'result' => 'success',
//                        'redirect' => $this->get_return_url($order),
                        'redirect' => $redirect_path,
                    );

                }
                throw new Exception(__('Error', 'wc-gateway-cannapaid'));
            }
            return array('result' => 'success', 'redirect' => $form_url);
        }

    } // end \WC_Gateway_CannaPaid class
}

add_action('plugins_loaded', 'wc_cannapaid_gateway_init', 11);

add_filter('http_request_timeout', 'wp9838c_timeout_extend');

function wp9838c_timeout_extend($time)
{
    // Default timeout is 5
    return 180;
}